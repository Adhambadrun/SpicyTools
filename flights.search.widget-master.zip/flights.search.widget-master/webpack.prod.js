const webpack = require('webpack');
const merge = require('webpack-merge');
const common = require('./webpack.common.js');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');

module.exports = merge(common, {
	mode: 'production',
	optimization: {
		minimizer: [
			new UglifyJsPlugin({
				uglifyOptions: {
					compress: {
						reduce_funcs: false
					}
				}
			})
		]
	},
	plugins: [
		new webpack.ContextReplacementPlugin(/moment[/\\]locale$/, /ru|en|de|ro|kk|uz|uk/),
		new webpack.optimize.OccurrenceOrderPlugin()
	]
});
