const webpack = require('webpack');
const path = require('path');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const packageJSON = require('./package.json');

const isDevMode = process.env.NODE_ENV === 'development';
const moduleName = 'flights.search.widget';

const extractSass = new ExtractTextPlugin({
	filename: `${moduleName}.min.css`
});

const extractNemoSass = new ExtractTextPlugin({
	filename: `nemo-${moduleName}.min.css`
});

module.exports = {
	context: __dirname,
	entry: {
		[moduleName]: ['whatwg-fetch', './src/main.tsx'],
		demo: './src/demo.tsx'
	},
	output: {
		path: path.resolve(__dirname, 'dist'),
		publicPath: '/',
		filename: '[name].min.js',
		library: 'FlightsSearchWidget',
		libraryTarget: 'umd'
	},
	performance: {
		hints: false
	},
	resolve: {
		modules: [
			'node_modules',
			path.resolve(__dirname, 'src'),
			path.resolve(__dirname, 'dist')
		],
		extensions: ['.ts', '.js', '.json', '.tsx', '.css', '.scss']
	},
	module: {
		rules: [
			{
				test: /\.tsx?$/,
				loader: 'ts-loader',
				include: [
					path.resolve(__dirname, 'src')
				],
				exclude: [
					path.resolve(__dirname, 'node_modules')
				]
			},
			{
				test: /\.scss$/,
				include: [
					path.resolve(__dirname, 'src/css')
				],
				exclude: [
					path.resolve(__dirname, 'src/css/nemo')
				],
				use: extractSass.extract({
					use: [
						{
							loader: 'css-loader',
							options: {
								minimize: !isDevMode
							}
						},
						'resolve-url-loader',
						'postcss-loader',
						'sass-loader'
					],
					fallback: 'style-loader',
					publicPath: path.resolve(__dirname, 'dist')
				})
			},
			{
				test: /\.scss$/,
				include: [
					path.resolve(__dirname, 'src/css/nemo')
				],
				use: extractNemoSass.extract({
					use: [
						{
							loader: 'css-loader',
							options: {
								minimize: !isDevMode
							}
						},
						'resolve-url-loader',
						'postcss-loader',
						'sass-loader'
					],
					fallback: 'style-loader',
					publicPath: path.resolve(__dirname, 'dist')
				})
			},
			{
				test: /\.woff$/,
				loader: 'url-loader',
				options: {
					limit: 50000,
					mimetype: 'application/font-woff'
				},
				include: [
					path.resolve(__dirname, 'src/css/fonts')
				]
			},
			{
				test: /\.svg$/,
				loader: 'url-loader',
				include: [
					path.resolve(__dirname, 'src/css/images'),
					path.resolve(__dirname, 'src/css/nemo/images')
				],
				options: {
					publicPath: '',
					outputPath: '',
					name: '/[name].[ext]'
				}
			}
		]
	},
	plugins: [
		extractSass,
		extractNemoSass,
		new webpack.DefinePlugin({
			'process.env': {
				NODE_ENV: JSON.stringify(isDevMode ? 'development' : 'production'),
				VERSION: JSON.stringify(packageJSON.version)
			}
		})
	]
};
