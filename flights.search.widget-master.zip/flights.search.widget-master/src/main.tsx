import './ponyfills';
import * as moment from 'moment';
import * as React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import { Store } from 'redux';
import 'whatwg-fetch';

import * as i18n from './i18n';
import Main from './components/Main';
import { cacheState, getStore } from './store';
import './css/main.scss';
import './css/nemo/main.scss';
import { ApplicationState, Language, SystemState } from './state';
import { enableCaching } from './store/system/actions';

let storeGlobal: Store<ApplicationState>;

/**
 * This will be exported to the global scope as `FlightsSearchWidget.init`.
 *
 * @param {SystemState} config
 */
export const init = (config: SystemState) => {
	if (!config.rootElement) {
		throw Error('Please specify `rootElement` parameter in the configuration object.');
	}

	if (!config.nemoURL) {
		throw Error('Please specify `nemoURL` parameter in the configuration object.');
	}

	// Fix ukrainian language code.
	if ((config.locale as string).toLocaleLowerCase() === 'ua') {
		config.locale = Language.Ukrainian;
	}

	if (config.locale !== Language.Russian) {
		// Pull current value of the DOY.
		const doy = moment.localeData(Language.English).firstDayOfYear();

		// Set monday as a first day of the week and restore the DOY value.
		moment.updateLocale(config.locale, {
			week: {
				dow: 1,
				doy: doy
			}
		});
	}

	const store = getStore(config);

	i18n.init(config.customTranslations);

	storeGlobal = store;

	render(
		<Provider store={store}>
			<Main/>
		</Provider>,
		config.rootElement
	);

	// Subscribe to new state updates and cache new state.
	store.subscribe(() => cacheState(store.getState()));
};

/**
 * Enable saving widget data in Local Storage if `disableCaching` disabled it
 */
export const enableCache = (): void => {
	storeGlobal.dispatch(enableCaching());
};

export { default as Component } from './components/Component';
