import moment = require('moment');
import { nemoFastSearch, nemoFastSearchPassengers, nemoFastSearchSegment } from '../actions';
import { getStore } from '../../../store';

const segment = {
	autocomplete: {
		departure: {
			airport: {
				IATA: 'MOW',
				isCity: true
			}
		},
		arrival: {
			airport: {
				IATA: 'SVO',
				isCity: false
			}
		}
	},
	departureDate: {
		isActive: true,
		date: moment('2018-12-01')
	}
};

const customState = {
	nemoURL: 'http://nemo'
};

describe('runNemoSearch', () => {
	it('should correct build Fast Search passengers info', () => {
		const passengers = {
			ADT: {
				code: 'ADT',
				count: 3
			},
			CLD: {
				code: 'CLD',
				count: 2
			}
		};

		expect(nemoFastSearchPassengers(passengers as any)).toEqual('ADT3CLD2');
	});

	describe('nemoFastSearchSegment', () => {
		it('should build FS segment for default nemo results page', () => {
			expect(nemoFastSearchSegment(segment as any)).toEqual('cMOWaSVO20181201');
		});

		it('should build FS segment for AWP nemo results page', () => {
			expect(nemoFastSearchSegment(segment as any, true)).toEqual('MOWSVO20181201');
		});
	});

	describe('runNemoSearch', () => {
		it('should build Fast Search for default nemo results page', () => {
			const store = getStore(customState),
				state = store.getState();

			state.form.segments = [segment as any];

			expect(nemoFastSearch(state)).toEqual('http://nemo/results/cMOWaSVO20181201ADT1-class=Economy');
		});

		it('should build Fast Search for AWP results page', () => {
			const store = getStore(customState),
				state = store.getState();

			state.form.segments = [segment as any];

			expect(nemoFastSearch(state, true)).toEqual('http://nemo/#/results/MOWSVO20181201ADT1-class=Economy');
		});
	});
});
