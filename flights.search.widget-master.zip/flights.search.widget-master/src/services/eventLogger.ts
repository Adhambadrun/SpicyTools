import 'custom-event-polyfill';

export enum SearchFormEvent {
	StartSearch = 'search',
	TripType = 'tripType.value',
	DirectFlight = 'directFlights.active',
	ServiceClass = 'serviceClass.value',
	VicinityDates = 'vicinityDates.active',
	NotValid = 'search.validationError'
}

const eventPrefix = 'analytics.searchForm.';

export const eventTap = (event: string, value: any = null) => {
	document.dispatchEvent(new CustomEvent(eventPrefix + event, {
		detail: value
	}));
};
